import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.http.SdkHttpClient;
import software.amazon.awssdk.http.TlsTrustManagersProvider;
import software.amazon.awssdk.http.async.SdkAsyncHttpClient;
import software.amazon.awssdk.http.nio.netty.NettyNioAsyncHttpClient;
import software.amazon.awssdk.http.nio.netty.ProxyConfiguration;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3AsyncClient;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.net.InetSocketAddress;
import java.net.URI;
import java.nio.file.Paths;
import java.security.cert.X509Certificate;

import io.netty.channel.Channel;
import io.netty.handler.proxy.Socks5ProxyHandler;

public class HcpS3Uploader {

    public static void main(String[] args) {
        // === CONFIG ===
        String hcpEndpoint = "https://s3.your-region.cloud.hashicorp.com";
        String accessKey = "...";
        String secretKey = "...";
        String bucket = "my-bucket";
        String key = "test.txt";
        String filePath = "/tmp/test.txt";

        // === Insecure TrustManager ===

        TlsTrustManagersProvider trustAllProvider = TrustAllTlsProvider.createTrustAllProvider();

        ProxyConfiguration proxyConfig = ProxyConfiguration.builder()
                .host("127.0.0.1")
                .port(1080)
                .scheme("socks5")
                .build();
        // === HTTP Client with SOCKS + Insecure Trust ===
        SdkAsyncHttpClient httpClient = NettyNioAsyncHttpClient.builder()
                .tlsTrustManagersProvider(trustAllProvider)
                .proxyConfiguration(proxyConfig)
                .build();

        // === S3 Client ===
        try (S3AsyncClient s3 = S3AsyncClient.builder()
                .endpointOverride(URI.create(hcpEndpoint))
                .credentialsProvider(StaticCredentialsProvider.create(
                        AwsBasicCredentials.create(accessKey, secretKey)
                ))
                .region(Region.US_EAST_1)
                .httpClient(httpClient)
                .forcePathStyle(true)
                .build()) {

            s3.putObject(
                    PutObjectRequest.builder().bucket(bucket).key(key).build(),
                    Paths.get(filePath)
            );
            System.out.println("Upload successful!");
        }
    }
}