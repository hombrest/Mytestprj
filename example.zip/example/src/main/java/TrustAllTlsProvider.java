import software.amazon.awssdk.http.TlsTrustManagersProvider;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.lang.reflect.Constructor;
import java.security.cert.X509Certificate;

public class TrustAllTlsProvider {

    public static TlsTrustManagersProvider createTrustAllProvider() {
        try {
            // Create a permissive TrustManager
            X509TrustManager trustAll = new X509TrustManager() {
                @Override
                public void checkClientTrusted(X509Certificate[] chain, String authType) {}
                @Override
                public void checkServerTrusted(X509Certificate[] chain, String authType) {}
                @Override
                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }
            };

            // Use reflection to access package-private constructor
            Constructor<TlsTrustManagersProvider> constructor =
                    TlsTrustManagersProvider.class.getDeclaredConstructor(TrustManager[].class);
            constructor.setAccessible(true);

            return constructor.newInstance((Object) new TrustManager[]{trustAll});

        } catch (Exception e) {
            throw new RuntimeException("Failed to create TlsTrustManagersProvider via reflection", e);
        }
    }
}