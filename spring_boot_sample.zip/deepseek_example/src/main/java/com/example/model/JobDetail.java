package com.example.model;

import lombok.Data;

@Data
public class JobDetail {
    private String jobKeyNo;
    private String title;
    private String duties;
    private String bd;
    // Add other fields as needed
}
