package com.example.service;

import com.example.model.JobDetail;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

import static org.apache.poi.ss.usermodel.CellType.NUMERIC;

@Service
public class ExcelService {
    private static final String FILE_PATH = "job_detail.xlsx";
    private static final String NEW_FILE_PATH = "new_job_detail.xlsx";
    private static final String SHEET_NAME = "Details";

    public Set<String> getExistingJobKeys() throws IOException {
        Set<String> keys = new HashSet<>();
        File file = new File(FILE_PATH);
        if (!file.exists()) return keys;

        try (Workbook workbook = new XSSFWorkbook(file)) {
            Sheet sheet = workbook.getSheet(SHEET_NAME);
            if (sheet == null) return keys;
            for (Row row : sheet) {
                Cell cell = row.getCell(0); // Assuming Job Key is first column
                if (cell != null) {
                    if (cell.getCellType() == NUMERIC) {
                        keys.add(String.valueOf((int) cell.getNumericCellValue()));
                    }
                    else {
                        keys.add(cell.getStringCellValue());
                    }

                }
            }
        } catch (InvalidFormatException e) {
            throw new RuntimeException(e);
        }
        return keys;
    }

    public void writeNewJobs(List<Map<String, String>> rows) throws IOException, InvalidFormatException {
        File file = new File(NEW_FILE_PATH);
        Workbook workbook;
        Sheet sheet;

        if (file.exists()) {
            workbook = new XSSFWorkbook(file);
            sheet = workbook.getSheet(SHEET_NAME);
        } else {
            workbook = new XSSFWorkbook();
            sheet = workbook.createSheet(SHEET_NAME);
        }

        if (!rows.isEmpty()) {
            Map<String, String> firstRow = rows.get(0);
            Row headerRow = sheet.createRow(0);
            List<String> headers = new ArrayList<>(firstRow.keySet());
            for (int i = 0; i < headers.size(); i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers.get(i));
            }
            // Write each data row
            for (int i = 0; i < rows.size(); i++) {
                Row row = sheet.createRow(i + 1);
                Map<String, String> rowData = rows.get(i);
                int cellIndex = 0;
                for (String header : firstRow.keySet()) {
                    Cell cell = row.createCell(cellIndex++);
                    cell.setCellValue(rowData.getOrDefault(header, ""));
                }
            }
        }

        try (FileOutputStream fos = new FileOutputStream(file)) {
            workbook.write(fos);
        }
        workbook.close();
    }
}
