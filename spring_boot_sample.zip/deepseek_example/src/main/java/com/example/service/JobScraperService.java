package com.example.service;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class JobScraperService {
    private static final Logger logger = LoggerFactory.getLogger(JobScraperService.class);

    @Autowired
    private CloseableHttpClient httpClient;

    @Autowired
    private ExcelService excelService;

    private static final String BASE_URL = "https://www.infotech.com.hk/itjs/job/fe-view.do?method=feView&jjKey=";
    private static final String SEARCH_URL = "https://infotech.com.hk/itjs/job/fe-search.do?method=feList&sortByField=jjm_activedate&sortByOrder=DESC";
    private static final int TIMEOUT_MILLISECONDS = 60000;

    private static final String[] EXCLUDED_FIELDS = {
            "Monthly Salary Range HK$", "Payroll", "Apply To", "Direct Line", "Employer Business"
    };

    @Async
    @Scheduled(fixedDelay = 86400000) // Run daily
    public void scrapeJobs() {
        logger.info("Starting job scraping process...");

        Set<String> searchKeys = new HashSet<>();
        Set<String> existingKeys;
        try {
            existingKeys = excelService.getExistingJobKeys();
        } catch (IOException e) {
            logger.error("Failed to read existing job keys from Excel file", e);
            return;
        }

        List<Map<String, String>> newJobs = new ArrayList<>();

        // Fetch job keys from search page
        HttpGet searchRequest = new HttpGet(SEARCH_URL);
        try (CloseableHttpResponse response = httpClient.execute(searchRequest)) {
            Document doc = Jsoup.parse(response.getEntity().getContent(), "UTF-8", SEARCH_URL);
            Elements links = doc.select("a");
            for (Element link : links) {
                String text = link.text();
                if (text.contains("Contract") && text.contains("Bid")) {
                    String href = link.attr("href");
                    int keyPos = href.indexOf("jjKey=");
                    if (keyPos >= 0) {
                        String key = href.substring(keyPos + 6);
                        searchKeys.add(key);
                        logger.debug("Found job key: {}", key);
                    }
                }
            }
        } catch (IOException e) {
            logger.error("Failed to fetch job keys from search page", e);
            return;
        }

        // Process each job
        for (String key : searchKeys) {
            if (!existingKeys.contains(key)) {
                logger.info("Processing job with key: {}", key);
                Map<String, String> job = extractJobDetail(BASE_URL + key);
                if (job != null) {
                    newJobs.add(job);
                    logger.debug("Extracted job details: {}", job);
                }
            } else {
                logger.debug("Skipping existing job with key: {}", key);
            }
        }

        if (!newJobs.isEmpty()) {
            try {
                excelService.writeNewJobs(newJobs);
                logger.info("Successfully wrote {} new jobs to Excel file", newJobs.size());
            } catch (IOException e) {
                logger.error("Failed to write new jobs to Excel file", e);
            } catch (InvalidFormatException e) {
                throw new RuntimeException(e);
            }
        } else {
            logger.info("No new jobs found to write to Excel file");
        }

        logger.info("Job scraping process completed.");
    }

    private Map<String, String> extractJobDetail(String jobUrl) {
        logger.debug("Extracting job details from URL: {}", jobUrl);

//        try {
//            HttpGet request = new HttpGet(jobUrl);
//            try (CloseableHttpResponse response = httpClient.execute(request)) {
//                Document doc = Jsoup.parse(response.getEntity().getContent(), "UTF-8", jobUrl);
//                Element form = doc.selectFirst("form[name=jobForm]");
//                if (form == null) {
//                    logger.warn("Form named 'jobForm' not found in URL: {}", jobUrl);
//                    return null;
//                }
//
//                Map<String, String> job = new LinkedHashMap<>();
//                Elements rows = form.select("tr");
//                for (Element row : rows) {
//                    Elements tds = row.select("td");
//                    if (tds.size() == 2) {
//                        String fieldName = tds.get(0).text().trim();
//                        String fieldData = tds.get(1).text().trim();
//
//                        if (!fieldName.isEmpty() && !IGNORED_FIELDS.contains(fieldName)) {
//                            job.put(fieldName, fieldData);
//                            if ("Duties".equals(fieldName)) {
//                                job.put("B/D", extractBd(fieldData));
//                            }
//                            if ("Job Title/ Category".equals(fieldName)) {
//                                job.put("Title", extractTitle(fieldData));
//                            }
//                        }
//
//                    }
//                }
//                return job;
//            }
//        } catch (IOException e) {
//            logger.error("Failed to extract job details from URL: {}", jobUrl, e);
//            return null;
//        }
        Map<String, String> data = new LinkedHashMap<>();
        try {
            Document doc = Jsoup.connect(jobUrl)
                    .timeout(TIMEOUT_MILLISECONDS)
                    .get();

            Element form = Optional.ofNullable(doc.selectFirst("form[name=jobForm]"))
                    .orElseThrow(() -> new IllegalStateException("Form not found"));

            form.select("tr").stream()
                    .map(row -> row.select("td"))
                    .filter(columns -> columns.size() == 2)
                    .forEach(columns -> processColumns(columns, data));

            return data;
        } catch (Exception e) {
            logger.error("Error extracting job details from {}: ", jobUrl, e);
            return null;
        }
    }

    private static void processColumns(Elements columns, Map<String, String> data) {
        String fieldName = columns.get(0).text().trim();
        String fieldData = columns.get(1).text().trim();

        if (!fieldName.isEmpty() && !Arrays.asList(EXCLUDED_FIELDS).contains(fieldName)) {
            data.put(fieldName, fieldData);

            if (fieldName.equals("Duties")) {
                data.put("B/D", extractBd(fieldData));
            }
            if (fieldName.equals("Job Title/ Category")) {
                data.put("Title", extractTitle(fieldData));
            }
        }
    }
    private static String extractTitle(String text) {
        int index = text.indexOf('(');
        if (index == -1) {
            logger.debug("No title abbreviation found in text: {}", text);
            return null;
        }
        String prefix = text.substring(0, index).trim();
        return Arrays.stream(prefix.split(" "))
                .map(word -> word.substring(0, 1))
                .collect(Collectors.joining());
    }

    private static String extractBd(String text) {
        int serveIndex = text.indexOf("serve the");
        if (serveIndex == -1) {
            logger.debug("No 'serve the' keyword found in text: {}", text);
            return null;
        }
        String substring = text.substring(serveIndex + 10);
        int newlineIndex = substring.indexOf(' ');
        if (newlineIndex == -1) {
            logger.debug("No space found after 'serve the' in text: {}", text);
            return null;
        }
        return substring.substring(0, newlineIndex).replace(";", "").trim();
    }
}