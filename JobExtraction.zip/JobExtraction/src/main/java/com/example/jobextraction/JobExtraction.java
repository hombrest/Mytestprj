package com.example.jobextraction;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class JobExtraction {
	
	private static final Logger logger = LogManager.getLogger(JobExtraction.class);

    public static void main(String[] args) {
        String url = "https://infotech.com.hk/itjs/job/fe-search.do?method=feList&sortByField=jjm_activedate&sortByOrder=DESC";
        String filePath = "job_detail.xlsx";
        String sheetName = "Details";

        try {
            // Fetch job keys from the main page
            Set<String> searchKeys = fetchJobKeys(url);

            // Read existing Excel file
            Workbook workbook;
            Sheet sheet;
            File file = new File(filePath);
            if (file.exists()) {
                workbook = WorkbookFactory.create(new FileInputStream(file));
                sheet = workbook.getSheet(sheetName);
            } else {
                workbook = new XSSFWorkbook();
                sheet = workbook.createSheet(sheetName);
            }

            // Extract job details
            List<Map<String, String>> rows = new ArrayList<>();
            String baseUrl = "https://www.infotech.com.hk/itjs/job/fe-view.do?method=feView&jjKey=";

            for (String key : searchKeys) {
                Map<String, String> job = extractJobDetail(baseUrl + key);
                if (job != null) {
                    rows.add(job);
                }
            }

            // Write new rows to Excel
            if (!rows.isEmpty()) {
                for (Map<String, String> row : rows) {
                    Row excelRow = sheet.createRow(sheet.getLastRowNum() + 1);
                    int cellIndex = 0;
                    for (Map.Entry<String, String> entry : row.entrySet()) {
                        excelRow.createCell(cellIndex++).setCellValue(entry.getValue());
                    }
                }

                try (FileOutputStream outputStream = new FileOutputStream(filePath)) {
                    workbook.write(outputStream);
                }
            } else {
                System.out.println("No new jobs found.");
            }

            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Set<String> fetchJobKeys(String url) throws IOException {
        Set<String> searchKeys = new HashSet<>();
        Document doc = Jsoup.connect(url).get();
        Elements links = doc.select("a");

        for (Element link : links) {
            String linkText = link.text();
            if (linkText.contains("Contract") && linkText.contains("Bid")) {
                String subUrl = link.attr("href");
                int keyPos = subUrl.indexOf("jjKey=");
                if (keyPos >= 0) {
                    searchKeys.add(subUrl.substring(keyPos + "jjKey=".length()));
                }
            }
        }

        return searchKeys;
    }

    private static Map<String, String> extractJobDetail(String jobUrl) {
        Map<String, String> data = new HashMap<>();
        try {
            Document doc = Jsoup.connect(jobUrl).timeout(10000).get();
            Element form = doc.selectFirst("form[name=jobForm]");

            if (form == null) {
                System.out.println("Form named 'jobForm' not found.");
                return null;
            }

            Elements rows = form.select("tr");
            for (Element row : rows) {
                Elements columns = row.select("td");
                if (columns.size() == 2) {
                    String fieldName = columns.get(0).text().trim();
                    String fieldData = columns.get(1).text().trim();

                    if (!fieldName.isEmpty() && !fieldName.equals("Monthly Salary Range HK$") &&
                            !fieldName.equals("Payroll") && !fieldName.equals("Apply To") &&
                            !fieldName.equals("Direct Line") && !fieldName.equals("Employer Business")) {
                        data.put(fieldName, fieldData);

                        if (fieldName.equals("Duties")) {
                            data.put("B/D", extractBd(fieldData));
                        }
                        if (fieldName.equals("Job Title/ Category")) {
                            data.put("Title", extractTitle(fieldData));
                        }
                    }
                }
            }

            return data;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static String extractTitle(String text) {
        int keywordIndex = text.indexOf('(');
        if (keywordIndex != -1) {
            String extractedString = text.substring(0, keywordIndex).trim();
            if (!extractedString.isEmpty()) {
                return Arrays.stream(extractedString.split(" "))
                        .map(word -> word.substring(0, 1))
                        .reduce("", String::concat);
            }
        }
        return null;
    }

    private static String extractBd(String text) {
        try {
            int keywordIndex1 = text.indexOf("serve the");
            if (keywordIndex1 == -1) {
                return null;
            }

            int keywordIndex2 = text.indexOf("\n", keywordIndex1);
            if (keywordIndex2 == -1) {
                keywordIndex2 = text.indexOf("\r", keywordIndex1);
            }

            if (keywordIndex2 != -1) {
                return text.substring(keywordIndex1 + "serve the ".length(), keywordIndex2).trim().replace(";", "");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}